package common;

public enum PatronType {
    REGULAR,
    PREMIUM
}
